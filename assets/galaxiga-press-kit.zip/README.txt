Galaxiga Retro Arcade Shooter
Developer: JNR Games
Platform: Android
Contains ads and in-app purchases.
Google Play: https://play.google.com/store/apps/details?id=com.jnr.galaxiga
Website: https://jnregames.github.io/
Support: recommsip@gmail.com

EN: A retro arcade space shooter with diving alien formations, power-ups, boss encounters, and high-score runs.
ES: Un juego de naves arcade con formaciones alienigenas, mejoras, combates contra jefes y partidas para superar tu propio record.

Screenshots are October 2026 development-build captures; the public build may differ. key-art.webp and icon.webp are promotional artwork, not gameplay captures. Permission: use these materials to cover or discuss Galaxiga, with credit to JNR Games.
